//
//  ProfileController.h
//  15Puzzle
//

#import <UIKit/UIKit.h>
#import "Board.h"

@interface ProfileController : UIViewController<UITextFieldDelegate>{
    Board *board;
    IBOutlet UITextField *textField;
    IBOutlet UIButton *savePlayer;
    IBOutlet UILabel *scoreLabel;
    IBOutlet UILabel *usernameLabel;
}

- (IBAction)savePlayerUsername;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil board:(Board *)aBoard;

@end
