//
//  CustomNavigationBarController.h
//  15Puzzle
//
//

#import <Foundation/Foundation.h>

@interface CustomNavigationBarController : UINavigationController

@end
