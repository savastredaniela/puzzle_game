//
//  ProfileController.m
//  15Puzzle
//

#import "ProfileController.h"
#import "Profile.h"

@implementation ProfileController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil board:(Board *)aBoard
{
	if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])
	{
		board = [aBoard retain];
		
		[self setTabBarItem:[[[UITabBarItem alloc] initWithTitle:NSLocalizedString(@"ProfileTitle", @"")
														   image:[UIImage imageNamed:@"profile.png"]
															 tag:kTabBarSettingsTag] autorelease]];
	}
    
    
	return self;
}

- (void)dealloc
{
	DLog("dealloc");

	[board release];
    [super dealloc];
}


-(void)viewDidLoad{
    [super viewDidLoad];
    textField.delegate = self;
    
    self.title = NSLocalizedString(@"ProfileTitle", @"");
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    
    scoreLabel.text = [NSString stringWithFormat:@"%d punti",[Profile scores]];
    textField.text = [Profile username];
    usernameLabel.text = [Profile username];
}


- (IBAction)savePlayerUsername{
    
    //Salvo l'utente e resetto il risultato
    [Profile setUsername:textField.text];
    usernameLabel.text = [Profile username];
    [Profile setScores: 0];
    scoreLabel.text = [NSString stringWithFormat:@"%d punti",[Profile scores]];
    
    
    UIAlertView *message = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"DataSaved",@"")
                                                      message:NSLocalizedString(@"DataSavedLarge",@"")
                                                     delegate:nil
                                            cancelButtonTitle:@"Ok"
                                            otherButtonTitles:nil];
    [message show];
    [message release];
    
    
    [textField resignFirstResponder];
}

- (BOOL) textFieldShouldReturn:(UITextField *)aTextField
{
    
    [textField resignFirstResponder];
    
    return YES;
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

-(NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskAllButUpsideDown;
}

-(BOOL)shouldAutorotate
{
    return YES;
}


@end
