//
//  Util.h
//

#import <UIKit/UIKit.h>

@interface Util : NSObject {}

+ (CGContextRef)newBitmapContextForWidth:(float)width height:(float)height;
+ (void)drawRoundedRectForPath:(CGMutablePathRef)path rect:(CGRect)rect radius:(float)radius;
+ (UIImageView *)createPausedViewWithFrame:(CGRect)frame;

@end
