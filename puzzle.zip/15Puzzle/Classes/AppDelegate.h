//
//  AppDelegate.h
//

#import <UIKit/UIKit.h>
#import "Board.h"

@class PuzzleViewController;

@interface AppDelegate : NSObject <UIApplicationDelegate>
{
	NSMutableArray *controllers;
	Board *board;
}

@end

