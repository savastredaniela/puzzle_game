//
//  PhotoController.h
//

#import <UIKit/UIKit.h>
#import "Board.h"
#import "PhotoDefaultController.h"

@class Board;

@interface PhotoController : UIViewController <UINavigationControllerDelegate, UIImagePickerControllerDelegate, UIAlertViewDelegate>
{
	UIBarButtonItem *photoLibraryButton;
	UIBarButtonItem *photoDefaultButton;
	UIImageView *selectImageView;
	Board *board;
}

@property (nonatomic, retain) UIBarButtonItem *photoLibraryButton;
@property (nonatomic, retain) UIBarButtonItem *photoDefaultButton;
@property (nonatomic, retain) UIImageView *selectImageView;

- (id)initWithBoard:(Board *)aBoard;
- (void)photoLibraryButtonAction;
- (void)photoDefaultButtonAction;
- (void)selectPhoto:(UIImage *)photo type:(int)type;


@end
