//
//  RulesViewController.m
//

#import "RulesViewController.h"
#import "Constants.h"


@implementation RulesViewController

@synthesize titleSite, toolbar, hiddenToolbar, urlSite;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil board:(Board *)aBoard
{
	if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])
	{
		board = [aBoard retain];
		
		[self setTabBarItem:[[[UITabBarItem alloc] initWithTitle:NSLocalizedString(@"RulesTitle", @"")
														   image:[UIImage imageNamed:@"rules.png"]
															 tag:kTabBarSettingsTag] autorelease]];
	}
	return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}



#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.toolbar.hidden = FALSE;
    
    NSString * indirizzo = kRulesWebURL;
     
    NSURL *url = [[[NSURL alloc] initWithString:indirizzo]autorelease];

    webView.scalesPageToFit = YES;
    webView.delegate = self;
    
    //crea un oggetto URL
    NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
    // visualizza la pagina nella UIWebView
    [webView loadRequest:requestObj];
    
    self.title = NSLocalizedString(@"RulesTitle", @"");
       
}



-(void)webViewDidStartLoad:(UIWebView *)webView {
	
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    [activityIndicator startAnimating];
}

-(void)webViewDidFinishLoad:(UIWebView *)webView{
	
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    [activityIndicator stopAnimating];
	
}

- (void)myWebView:(UIWebView *)myWebView didFailLoadWithError:(NSError *)error
{
	// load error, hide the activity indicator in the status bar
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
	
	// report the error inside the webview
	NSString* errorString = [NSString stringWithFormat:
							 @"<html><center><font size=+5 color='red'>Si &egrave; verificato un errore:<br>%@</font></center></html>",
							 error.localizedDescription];
	[webView loadHTMLString:errorString baseURL:nil];
}

- (void)viewDidUnload
{
    [super viewDidUnload];

    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    [activityIndicator stopAnimating];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


-(void) dealloc{

    [webView release];
    //[urlSite release];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    [activityIndicator stopAnimating];
    //[titleSite release];
    [toolbar release];
    [super dealloc];
    
}

@end
