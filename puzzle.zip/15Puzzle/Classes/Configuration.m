//
//  Configuration.m
//

#import "Configuration.h"


@implementation Configuration

@synthesize columns;
@synthesize rows;
@synthesize photoType;
@synthesize photoEnabled;
@synthesize numbersEnabled;

- (id)initWithBoard:(Board *)aBoard
{
	if (self = [super init])
	{
		board = [aBoard retain];
	}
	return self;
}

- (void)dealloc
{
	DLog("dealloc");
	[board release];
	[super dealloc];
}

- (void)load
{
	DLog("Carica configurazione");

	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	
	bool savedDefaults = [defaults boolForKey:kKeySavedDefaults];
	if (savedDefaults)
	{
		columns = [defaults integerForKey:kKeyColumns];
		if (columns == 0) columns = kColumnsDefault;
		
		rows = [defaults integerForKey:kKeyRows];
		if (rows == 0) rows = kRowsDefault;
		
		photoType = [defaults integerForKey:kKeylastPhotoType];
		photoEnabled = [defaults boolForKey:kKeyPhotoEnabled];
		numbersEnabled = [defaults boolForKey:kKeyNumbersEnabled];
	}
	else
	{
		columns = kColumnsDefault;
		rows = kRowsDefault;
		photoType = klastPhotoTypeDefault;
		photoEnabled = kPhotoEnabledDefault;
		numbersEnabled = kNumbersEnabledDefault;
	}
}

- (void)save
{
	DLog("Salva configurazione");
	BOOL restart = NO;
	
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	
	if ([defaults integerForKey:kKeyColumns] != columns) { restart = YES; }
	if ([defaults integerForKey:kKeyRows] != rows) { restart = YES; }

	[defaults setBool:YES forKey:kKeySavedDefaults];
	[defaults setInteger:columns forKey:kKeyColumns];
	[defaults setInteger:rows forKey:kKeyRows];
	[defaults setInteger:photoType forKey:kKeylastPhotoType];
	[defaults setBool:photoEnabled forKey:kKeyPhotoEnabled];
	[defaults setBool:numbersEnabled forKey:kKeyNumbersEnabled];
	[defaults synchronize];
	
	[board configChanged:restart];
}

@end
