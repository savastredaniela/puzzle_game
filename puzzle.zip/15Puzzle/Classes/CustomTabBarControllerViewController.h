//
//  CustomTabBarControllerViewController.h
//  

#import <UIKit/UIKit.h>

@interface CustomTabBarControllerViewController : UITabBarController{
    IBOutlet UITabBar *tabBar;
}

@property(nonatomic, retain) UITabBar *tabBar;

@end
