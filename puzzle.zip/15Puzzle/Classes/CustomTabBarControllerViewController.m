//
//  CustomTabBarControllerViewController.m
//
//

#import "CustomTabBarControllerViewController.h"

@interface CustomTabBarControllerViewController ()

@end

@implementation CustomTabBarControllerViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)hideExistingTabBar
{
	for(UIView *view in self.view.subviews)
	{
		if([view isKindOfClass:[UITabBar class]])
		{
			view.hidden = YES;
			break;
		}
	}
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    /*
    [self hideExistingTabBar];
    
    CGRect frame = CGRectMake(0.0, 100.0, self.view.bounds.size.width, 48);
	UIView *v = [[UIView alloc] initWithFrame:frame];
	[v setBackgroundColor:[UIColor blueColor]]; //003366
	[v setAlpha:1.0];
	[[self.tabBarController tabBar] addSubview:v];
	[v release];
     */

}


// iOS6 support
// ---
-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // You do not need this method if you are not supporting earlier iOS Versions
    return [self.selectedViewController shouldAutorotateToInterfaceOrientation:interfaceOrientation];
}

-(NSUInteger)supportedInterfaceOrientations
{
    return [self.selectedViewController supportedInterfaceOrientations];
}

-(BOOL)shouldAutorotate
{
    return YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
