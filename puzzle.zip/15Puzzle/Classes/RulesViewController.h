//
//  RulesViewController.h
//

#import <UIKit/UIKit.h>
#import "Board.h"

@interface RulesViewController : UIViewController<UIWebViewDelegate> {
   
    IBOutlet UIWebView *webView;
    IBOutlet UIActivityIndicatorView *activityIndicator;
    IBOutlet UIToolbar *toolbar;
    
    NSString *urlSite;
    NSString *titleSite;
    BOOL hiddenToolbar;
    Board *board;

}

@property (nonatomic, assign)  NSString  *urlSite;
@property (nonatomic, retain)  NSString  *titleSite;
@property (nonatomic, retain)  UIToolbar *toolbar;
@property (nonatomic) BOOL hiddenToolbar;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil board:(Board *)aBoard;

@end
