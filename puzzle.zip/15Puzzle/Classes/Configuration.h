//
//  Configuration.h
//


#import <UIKit/UIKit.h>
#import "Constants.h"
#import "Board.h"

@class Board;

@interface Configuration : NSObject
{
	int columns;
	int rows;
	int photoType;
	BOOL photoEnabled;
	BOOL numbersEnabled;
	Board *board;
}

@property (nonatomic, assign) int columns;
@property (nonatomic, assign) int rows;
@property (nonatomic, assign) int photoType;
@property (nonatomic, assign) BOOL photoEnabled;
@property (nonatomic, assign) BOOL numbersEnabled;

- (id)initWithBoard:(Board *)aBoard;
- (void)load;
- (void)save;

@end
