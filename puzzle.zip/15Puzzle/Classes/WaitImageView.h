//
//  WaitImageView.h
//

#import <UIKit/UIKit.h>
#import "Constants.h"
#import "Util.h"

#define kWaitViewX               0.0f
//#define kWaitViewY               20.0f
#define kWaitViewY               00.0f
#define kWaitViewWidth           320.0f
#define kWaitViewHeight          411.0f

#define kWaitViewDialogX         35.0f
#define kWaitViewDialogY         145.0f
#define kWaitViewDialogWidth     250.0f
#define kWaitViewDialogHeight    120.0f

#define kWaitIndicatorX          110.0f
#define kWaitIndicatorY          30.0f
#define kWaitIndicatorWidth      37.0f
#define kWaitIndicatorHeight     37.0f

#define kWaitBgColorRed          55.0f/255.0f
#define kWaitBgColorGreen        182.0f/255.0f
#define kWaitBgColorBlue         206.0f/255.0f
#define kWaitBgColorAlpha        1.0f

#define kWaitViewFontType        "Helvetica Neue"
#define kWaitViewFontSize        26

@interface WaitImageView : UIImageView
{
	UIActivityIndicatorView *activityIndicator;
}

- (void)startAnimating;
- (void)stopAnimating;

@end
