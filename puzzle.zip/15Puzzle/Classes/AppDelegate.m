//
//  AppDelegate.m
//

#import "AppDelegate.h"
#import "Constants.h"
#import "BoardController.h"
#import "PhotoController.h"
#import "SettingsController.h"
#import "RulesViewController.h"
#import "ProfileController.h"
#import "Board.h"
#import "CustomTabBarControllerViewController.h"
#import "CustomNavigationBarController.h"



@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{    
//- (void)applicationDidFinishLaunching:(UIApplication *)application
	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	controllers = [[NSMutableArray alloc] init];
	
	board = [[Board alloc] init];
	
	BoardController *boardController = [[BoardController alloc] initWithBoard:board];
	PhotoController *photoController = [[PhotoController alloc] initWithBoard:board];
	SettingsController *settingsController = [[SettingsController alloc] initWithNibName:@"SettingsView" bundle:nil board:board];
    ProfileController *profileController = [[ProfileController alloc] initWithNibName:@"ProfileView" bundle:nil board:board];
    RulesViewController *rulesController = [[RulesViewController alloc] initWithNibName:@"RulesView" bundle:nil board:board];
	
	CustomNavigationBarController *navController;
	
	navController = [[CustomNavigationBarController alloc] initWithRootViewController:boardController];
	[navController setNavigationBarHidden:YES];
	[[navController navigationBar] setBarStyle:UIBarStyleBlackTranslucent];
	[controllers addObject:navController];
	[navController release];
	
	navController = [[CustomNavigationBarController alloc] initWithRootViewController:photoController];
	[[navController navigationBar] setBarStyle:UIBarStyleBlackTranslucent];
	[controllers addObject:navController];
	[navController release];
	
	navController = [[CustomNavigationBarController alloc] initWithRootViewController:settingsController];
	[[navController navigationBar] setBarStyle:UIBarStyleBlackTranslucent];
	[controllers addObject:navController];
	[navController release];
    
    navController = [[CustomNavigationBarController alloc] initWithRootViewController:profileController];
	[[navController navigationBar] setBarStyle:UIBarStyleBlackOpaque];
	[controllers addObject:navController];
	[navController release];
    
    navController = [[CustomNavigationBarController alloc] initWithRootViewController:rulesController];
	[[navController navigationBar] setBarStyle:UIBarStyleBlackOpaque];
	[controllers addObject:navController];
	[navController release];
		
	[boardController release];
	[photoController release];
	[settingsController release];
    [profileController release];
    [rulesController release];
	
	CustomTabBarControllerViewController *tabBarController = [[CustomTabBarControllerViewController alloc] init];
	[tabBarController setViewControllers:controllers];
		
	//[window addSubview:tabBarController.view];
    //[window makeKeyAndVisible];
    
    window.rootViewController = tabBarController;
    [window makeKeyAndVisible];

	
	[board createNewBoard];
	
    return YES;
}

//FOR iOS>6.0
- (NSUInteger)application:(UIApplication*)application supportedInterfaceOrientationsForWindow:(UIWindow*)window
{
    return UIInterfaceOrientationMaskAll;
}

- (void)applicationWillTerminate:(UIApplication *)application
{
	DLog("applicationWillTerminate");
	[board saveBoard];
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
	DLog("applicationDidEnterBackground");
	[board saveBoard];	
}

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application
{
	DLog("applicationDidReceiveMemoryWarning");
}

- (void)dealloc
{
	DLog("dealloc");
	[board release];
	[controllers release];
    [super dealloc];
}

@end
