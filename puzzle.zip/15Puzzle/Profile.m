//
//  Profile.m
//  15Puzzle
//

#import "Profile.h"

@implementation Profile


+ (NSInteger)scores
{
    // Does preference exist...
    if ([[NSUserDefaults standardUserDefaults] integerForKey:@"userScore"] != 0)
        return [[NSUserDefaults standardUserDefaults] integerForKey:@"userScore"];
    else
        return 0;   // Default
}

+ (BOOL) setScores:(NSInteger)score
{

    [[NSUserDefaults standardUserDefaults] setInteger:score forKey:@"userScore"];
    
    return [[NSUserDefaults standardUserDefaults] synchronize];
}


+ (NSString*)username
{
    // Does preference exist...
    if ([[NSUserDefaults standardUserDefaults] stringForKey:@"username"] != nil)
        return [[NSUserDefaults standardUserDefaults] stringForKey:@"username"];
    else
        return @"";   // Default
}

+ (BOOL) setUsername:(NSString*)username
{
    
    [[NSUserDefaults standardUserDefaults] setValue:username forKey:@"username"];
    
    return [[NSUserDefaults standardUserDefaults] synchronize];
}

@end
