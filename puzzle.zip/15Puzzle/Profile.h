//
//  Profile.h
//  15Puzzle
//
//

#import <Foundation/Foundation.h>

@interface Profile : NSObject

+ (NSInteger)scores;
+ (NSString*)username;
+ (BOOL) setScores:(NSInteger)score;
+ (BOOL) setUsername:(NSString*)username;

@end
